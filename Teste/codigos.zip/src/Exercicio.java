import java.util.Scanner;

public class Exercicio {
    public static void main(String[] args) {
        Scanner leitor = new Scanner(System.in);
        int[] idade = new int[5];
        String[] nome = new String[5];

        for (int i = 0; i < nome.length; i++) {
            System.out.format("Digite o nome %d:\n", i + 1);
            nome[i] = leitor.nextLine();
            System.out.format("Digite a idade:\n");
            idade[i] = Integer.parseInt(leitor.nextLine());
        }
        leitor.close();

        for (int i = 0; i < idade.length - 1; i++) {
            for (int j = 0; j < idade.length - i - 1; j++) {
                if (idade[j] < idade[j + 1]) {
                    int tempIdade = idade[j];
                    String tempNome = nome[j];
                    idade[j] = idade[j + 1];
                    nome[j] = nome[j + 1];
                    idade[j + 1] = tempIdade;
                    nome[j + 1] = tempNome;
                }
            }
        }

        for (int i = 0; i < nome.length; i++) {
            System.out.format("Nome: %s, Idade: %d%n", nome[i], idade[i]);
        }
    }
}
