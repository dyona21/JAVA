import java.util.Scanner;
public class Exe {
    public static void main(String[] args) {
        Scanner ler = new Scanner(System.in);
        int[] vet = new int[5];
        float media = 0;
        System.out.format("Digite os 5 valores abaixo:\n ");
        for(int i = 0; i < vet.length; i++){
            vet[i] = ler.nextInt();
            media+=vet[i];
        }

        System.out.format("O valor da média é:%.2f ", media/5);

        ler.close();
    
    }

}
