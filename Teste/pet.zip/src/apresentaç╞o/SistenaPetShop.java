package apresentação;
import java.util.Scanner;
import dados.*;

public class SistenaPetShop {
    private static Veterinario []veterinarios = new Veterinario[50];
    private static int quantidadeVeterinarios = 0;
        
    public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		int escolha = -1;
        //laço de repetição para executar o sistema        
		while (escolha != 8) {
	            System.out.format("1. Cadastrar veterinário.\n");
	            System.out.format("2. Cadastrar dono.\n");
	            System.out.format("3. Mostrar veterinários.\n");
	            System.out.format("4. Cadastrar endereço veterinário.\n");
	            System.out.format("5. Cadastrar animal para o veterinário.\n");
	            System.out.format("6. Cadastrar endereço dono.\n");
	            System.out.format("7. Mostrar animais.\n");
	            System.out.format("8. Sair do programa.\n");
	            escolha = Integer.parseInt(in.nextLine());

                switch (escolha) {
                    case 1:
                        cadastrarVeterinario();
                        break;
                    case 2:
                        cadastrarDono();
                        break;
                    case 3:
                        mostrarVeterinarios();
                        break;
                    case 4:
                        cadastrarEnderecoVeterinario();
                        break;
                    case 5:
                        cadastrarAnimal();
                        break;
                    case 6:
                        cadastrarEnderecoDono();
                        break;
                    case 7:
                        mostrarAnimais();
                        break;
                    case 8:
                        System.out.format("Encerrando o programa.\n");
                        return;
                    default:
                        System.out.format("Escolha inválida. Tente novamente.\n"); 
                }
            }
        }
    

    //Método para cadrastrar o veterinário 
    public static void cadastrarVeterinario(){
        Scanner ler = new Scanner(System.in);

        System.out.format("Cadastro de Veterinário\n");
        System.out.format("Nome do Veterinário:\n");
        String nome = ler.nextLine();

        System.out.print("Salário do Veterinário:\n");
        double salario = ler.nextDouble();

        // Cria um novo objeto Veterinario
        Veterinario novoVeterinario = new Veterinario();
        novoVeterinario.setNome3(nome);
        novoVeterinario.setSalario(salario);

        // Adiciona o novo veterinário ao array
        if (quantidadeVeterinarios < veterinarios.length) {
            veterinarios[quantidadeVeterinarios] = novoVeterinario;
            quantidadeVeterinarios++;
            System.out.println("Veterinário cadastrado com sucesso!\n");
        } else {
            System.out.println("Limite de veterinários atingido. Não é possível cadastrar mais.\n");
        }
       
    }
    //Método para mostrar os veterinários já cadastrados
    public static void mostrarVeterinarios(){
        if(quantidadeVeterinarios == 0){
            System.out.format("Não há veterinários cadastrados.\n");
            return;
        }
        for(int i = 0; i < quantidadeVeterinarios; i++){
            System.out.format("Veterinário %d = %s\n", i+1, veterinarios[i].getNome3());
        }
        System.out.format("Todos os veterinários listados.\n");
    }

    public static void cadastrarEnderecoVeterinario(){
        Scanner ler = new Scanner(System.in);
        
        if (quantidadeVeterinarios == 0) {
            System.out.println("Não há veterinários cadastrados.\n");
            return;
        }
        //mostrando os veterinários cadastrados
        System.out.format("Lista dos veterinarios:\n");
        for(int i = 0; i < quantidadeVeterinarios; i++){
            System.out.format("Veterinario %d = %s\n", i+1, veterinarios[i].getNome3());
        }
        System.out.format("Esses são os veterinarios cadastrados, escolha de acordo com o número.\n");
        
        int escolhaVeterinario = Integer.parseInt(ler.nextLine());
        //Atribuindo o veterinário escolhido a uma nova variável 
        Veterinario veterinarioEscolhido = new Veterinario();
        veterinarioEscolhido = veterinarios[escolhaVeterinario - 1];        
        //lendo informações sobre o endereço
        System.out.format("Cadastrando o endereco do(a) %s\n", veterinarioEscolhido.getNome3());
        
        System.out.format("Rua:\n");
        String rua = ler.nextLine();
        System.out.format("Numero:\n");
        int numero = Integer.parseInt(ler.nextLine());
        System.out.format("Bairro\n");
        String bairro = ler.nextLine();
        System.out.format("Cidade:\n");
        String cidade = ler.nextLine();
        System.out.format("Estado:\n");
        String estado = ler.nextLine();
        System.out.format("CEP:\n");
        int cep = Integer.parseInt(ler.nextLine());

        Endereco informacoesEndereco = new Endereco(); 
        //Atribuindo as informações aos atributos da classe veterinário
        informacoesEndereco.setRua(rua);
        informacoesEndereco.setNumero(numero);
        informacoesEndereco.setBairro(bairro);
        informacoesEndereco.setCidade(cidade);
        informacoesEndereco.setEstado(estado);
        informacoesEndereco.setCep(cep);
        //Atribuindo as informações de endereço para o veterinario escolhido
        veterinarioEscolhido.setEndereco(informacoesEndereco);

    }
    //Cadastramento dos animais em determinado veterinário escolhido pelo usuário

    public static void cadastrarAnimal() {
        Scanner ler = new Scanner(System.in);
        Animal animal = new Animal();
        Dono dono = new Dono();
        if (quantidadeVeterinarios == 0) {
            System.out.println("Impossível cadastrar animal. Não há veterinários cadastrados.\n");
            return;
        }

        // Listando os veterinários
        System.out.println("Lista dos veterinários:\n");
        for (int i = 0; i < quantidadeVeterinarios; i++) {
            System.out.format("Veterinário %d = %s\n", i + 1, veterinarios[i].getNome3());
        }
        System.out.println("Escolha em qual veterinário você quer cadastrar seu animal.\n");
        int escolhaDeVeterinario = Integer.parseInt(ler.nextLine());

        // Atribuindo o veterinário escolhido para uma nova variável veterinário
        Veterinario novoVeterinario = veterinarios[escolhaDeVeterinario - 1];

        // Requisitando informações sobre o animal
        System.out.println("Digite as informações do animal:\n");
        System.out.println("Nome:\n");
        String nome = ler.nextLine();
        System.out.println("Dono:\n");
        String nomeDono = ler.nextLine();
        System.out.println("Espécie:\n");
        String especie = ler.nextLine();
        System.out.println("Descrição:\n");
        String descricao = ler.nextLine();
    
        // Criando um novo Dono
        dono.setNome1(nomeDono);
        // Criando uma variável animal e atribuindo valores para os atributos dela
        animal.setNome2(nome); 
        animal.setEspecie(especie);
        animal.setDono(dono);
        animal.setDescricao(descricao);
        // Adicionando o animal ao veterinário
        novoVeterinario.setAnimais(animal);
        System.out.format("Animal cadastrado com sucesso!\n");

    }
    //Função para mostrar os animais
    public static void mostrarAnimais(){
        Scanner ler = new Scanner(System.in);
        //imprimindo a lista de veterinários
        if(quantidadeVeterinarios == 0 ){
            System.out.format("Não há animais cadastrados.\n");
            return;
        }
        System.out.format("Lista dos veterinarios:\n");
        for(int i = 0; i < quantidadeVeterinarios; i++){
            System.out.format("Veterinario %d = %s\n", i+1, veterinarios[i].getNome3());
        }
        System.out.format("Esses são os veterinarios cadastrados, escolha de acordo com o número.\n");
    
        System.out.format("Escolha o número do veterinário para mostrar os animais atendidos por ele:\n");
        int escolha = Integer.parseInt(ler.nextLine());
        //selecionando o veterinario escolhido pelo usuário
        Veterinario veterinario = veterinarios[escolha - 1];

        System.out.format("Animais atendidos pelo veterinario %s\n", veterinario.getNome3());
        //printando na tela os animais atendidos por veterinários
        Animal[] animaisAtendidos = veterinario.getAnimais(); //atribuição dos animais que o veterinário escolhido atendeu
        for(int i = 0; i < animaisAtendidos.length; i++){
            System.out.format ("Animal %d %s\n", i+1, animaisAtendidos[i].getNome2());
        }
       
    }
    
    public static void cadastrarDono(){
        Scanner ler = new Scanner(System.in);
        Veterinario veterinario = new Veterinario();
        
        if(quantidadeVeterinarios > 0){
            System.out.format("Lista dos veterinarios:\n");
            //listando os veterinários 
            for(int i = 0; i < quantidadeVeterinarios; i++){
                System.out.format("Veterinario %d = %s\n", i+1, veterinarios[i].getNome3());
            }
            
            System.out.format("Escolha o número do veterinário para cadastrar o dono do animal.\n");
            int escolhaVeterinario = Integer.parseInt(ler.nextLine()); 
            veterinario = veterinarios[escolhaVeterinario - 1];
            
            if(veterinario.getQuantidadeAnimais() == 0 ){
                System.out.format("Impossível continuar, não há animais cadastrados.\n");
                return;
            }
            mostrarAnimais();
            System.out.format("Faça a escolha do animal que você quer cadastrar o dono.\n");
            int escolhaAnimal = Integer.parseInt(ler.nextLine()); 
            //primeiro atribuindo o veterinário escolhido a variável veterinário
            
            //atribuindo os animais do determinado veterinário para o novo vetor de animais 
            Animal []animais = veterinario.getAnimais();
            //selecionando o animal escolhido pelo usuário
            Animal animal = animais[escolhaAnimal - 1];
            //pegando as informações do dono do animal    
            System.out.println("Digite o nome do dono:\n");
                String nome = ler.nextLine();
                System.out.println("Digite o CPF do dono:\n");
                String cpf = ler.nextLine();
                //guardando as informações sobre o dono
                Dono dono = new Dono();
                dono.setNome1(nome);
                dono.setCpf(cpf);

                animal.setDono(dono);
                System.out.format("Dono cadastrado com sucesso para o animal %s.\n", animal.getNome2());
        } else {
            System.out.println("Opção inválida.");
        }
        
    }
   
    public static void cadastrarEnderecoDono(){
        Scanner ler = new Scanner(System.in);
        Veterinario veterinario = new Veterinario();

        if(quantidadeVeterinarios == 0){
            System.out.format("Não há veterinários cadastrados.\n");
            return; 
        }
        
        System.out.format("Escolha o número do veterinário para cadastrar o endereço do dono do animal.\n");
        int escolhaVeterinario = Integer.parseInt(ler.nextLine()); 
        //primeiro atribuindo o veterinário escolhido a variável veterinário
        veterinario = veterinarios[escolhaVeterinario - 1];
        mostrarAnimais();
        System.out.format("Faça a escolha do animal que você quer cadastrar o dono (escolha numérica).\n");
        int escolhaAnimal = Integer.parseInt(ler.nextLine());
        
        //atribuindo os animais do determinado veterinário para o novo vetor de animais 
        Animal []animais = veterinario.getAnimais();
        //selecionando o animal escolhido pelo usuário
        Animal animal = animais[escolhaAnimal - 1];
        Dono dono = new Dono();
        dono = animal.getDono();
        System.out.format("O nome e cpf do dono seguem abaixo.\n");
        System.out.format("%s\n", dono.getNome1());
        System.out.format("%s\n", dono.getCpf());
        
        //pegando as informações do dono do animal    
        System.out.println("Rua:\n");
        String rua = ler.nextLine();
        System.out.println("Número:\n");
        int numero = Integer.parseInt(ler.nextLine());
        System.out.println("Bairro:\n");
        String bairro = ler.nextLine();
        System.out.println("Cidade:\n");
        String cidade = ler.nextLine();
        System.out.println("Estado:\n");
        String estado = ler.nextLine();
        System.out.println("CEP:\n");
        int cep = Integer.parseInt(ler.nextLine());

        Endereco endereco = new Endereco();
        endereco.setBairro(bairro);
        endereco.setCep(cep);
        endereco.setCidade(cidade);
        endereco.setEstado(estado);
        endereco.setNumero(numero);
        endereco.setRua(rua);

        dono.setEndereco(endereco);

        System.out.format("Endereço cadastrado com sucesso.\n");

    
    }

}
