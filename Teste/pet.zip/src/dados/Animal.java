package dados;

public class Animal{
    private String nome2;
    private Dono dono;
    private String especie;
    private String descricao;

    public void setNome2(String nome){
        this.nome2 = nome;
    }

    public String getNome2(){
        return nome2;
    }

    public void setDono(Dono dono){
        this.dono = dono;
    }

    public Dono getDono(){
        return dono;
    }

    public void setEspecie(String especie){
        this.especie = especie;
    }
    
    public String getEspecie(){
        return especie;
    }

    public void setDescricao(String descricao){
        this.descricao = descricao;
    }

    public String getDescricao(){
        return descricao;
    }

}