package dados;

public class Dono{
    private String nome1;
    private Endereco endereco;
    private String cpf;

    public void setNome1(String nome){
        this.nome1 = nome;
    }

    public String getNome1(){
        return nome1;
    }

    public void setEndereco(Endereco endereco){
        this.endereco = endereco;
    }

    public Endereco getEndereco(){
        return endereco;
    }
    
    public void setCpf(String cpf){
        this.cpf = cpf;
    }

    public String getCpf(){
        return cpf;
    }
}