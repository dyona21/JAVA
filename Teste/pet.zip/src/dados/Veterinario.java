package dados;
import java.util.Arrays;

public class Veterinario{
    private String nome3;
    private double salario;
    private Endereco endereco;
    private int quantidadeAnimais = 0;
    private Animal []animais = new Animal[50];
   
    public void setAnimais(Animal animal){
        this.animais[quantidadeAnimais] = animal;
        quantidadeAnimais++;
    }

    public Animal[] getAnimais() {
        return Arrays.copyOf(animais, quantidadeAnimais);
    }
    
    public void setNome3(String nome){
        this.nome3 = nome;
    }

    public String getNome3(){
        return nome3;
    }

    public void setSalario(double salario){
        this.salario = salario;
    }    
    
    public double getSalario(){
        return salario;
    }

    public void setEndereco(Endereco endereco){
        this.endereco = endereco;
    }
    
    public Endereco getEndereco(){
        return endereco;
    }
    
    public int getQuantidadeAnimais(){
        return quantidadeAnimais;
    }

}