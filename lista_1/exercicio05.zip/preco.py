produto1 = Produto(101, "Arroz", 5.99)
produto2 = Produto(102, "Feijão", 3.49)

cliente1 = Cliente(201, "João", "Rua A, 123")
cliente2 = Cliente(202, "Maria", "Avenida B, 456")

print("Informações do Produto 1:")
print(produto1)

print("\nInformações do Produto 2:")
print(produto2)

print("\nInformações do Cliente 1:")
print(cliente1)

print("\nInformações do Cliente 2:")
print(cliente2)
