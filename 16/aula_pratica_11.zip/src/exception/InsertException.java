package exception;

public class InsertException extends Exception {

    public InsertException() {
        super("Erro durante a leitura do arquivo");
    }

}