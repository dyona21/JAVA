package exeções;

public class EspacoIndisponivelException extends Exception {
    public EspacoIndisponivelException(String mensagem) {
        super(mensagem);
    }
}
