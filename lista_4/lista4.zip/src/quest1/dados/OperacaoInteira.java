package quest1.dados;
public interface OperacaoInteira {
    public int executar(int valor1, int valor2);
}
