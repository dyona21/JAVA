package quest1.dados;
public class Soma implements OperacaoInteira {

    
    
    public int executar(int valor1, int valor2) {
        return valor1 + valor2;
    }
}
    


