package quest3;

public class NomeInvalidoException extends Exception{
    public NomeInvalidoException(String mensagem){
        super(mensagem);
    }
}
