package quest2.Exception;

public class PilhaVaziaException extends Exception {
    public PilhaVaziaException(String mensagem){
        super(mensagem);
    }
}
