package quest2.Exception;

public class ProcessoSemJuizException extends Exception {
    public ProcessoSemJuizException(String mensagem){
        super(mensagem);
    }
}
