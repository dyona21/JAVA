class Pessoa:
    def __init__(self, nome):
        self.nome = nome